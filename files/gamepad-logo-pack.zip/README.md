# Pack de logos - Mando retro

| Archivo | Uso |
|---|---|
| logo-principal.svg | Logo completo con degradados (cabeceras, landing, onboarding) |
| isotipo.svg | Silueta de un solo color con recortes (avatar, app icon, espacios pequeños) |
| favicon-32.svg / favicon-16.svg | Favicons optimizados para 32 y 16 px |
| favicon-32.png / favicon-16.png | Equivalentes PNG ya rasterizados |
| mono-blanco-fondo-oscuro.svg | Monocromático blanco para fondos oscuros |
| mono-oscuro-fondo-claro.svg | Monocromático oscuro para fondos claros |

## Integración (React / Vite)
```html
<link rel="icon" type="image/svg+xml" sizes="any" href="/favicon-32.svg" />
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32.png" />
<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16.png" />
```
```jsx
<img src="/assets/logo-principal.svg" alt="GameTracker" className="w-48 h-auto" />
```
El color del isotipo es #5B4BDB: cámbialo editando el atributo `fill`.
